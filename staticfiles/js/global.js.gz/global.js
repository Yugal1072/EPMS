function employeeRegistration() {
    alert("Employee Registration Successfull!");
}


function employeeUpdate() {
    alert("Employee Profile Updated Successfull!")
}

function loginUsername() {
    alert("Username doesn't Exist!")
}

function loginIncorrect() {
    alert("Invalid Password!")
}

function loginSuccess() {
    alert("Invalid Password!")
}


